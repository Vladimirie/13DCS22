﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace generikusok
{

    class DataStrone<T>
    {
        public T Data { get; set; }
        // public T[] datas = new T[10];
        private T[] _datas = new T[10];

        public void AddorUpdate(int index, T item)
        {

            if (index >= 0 && index < 10)
            {

                _datas[index] = item;
            }
        }

        public T Getdata(int index) {


            if (index >= 0 && index < 10)
            {
                return _datas[index];
            }
            else {
                return default;
            }
        }
    }
        internal class Program
        {
            static void Main(string[] args)
            {

                DataStrone<string> strone = new DataStrone<string>();


                strone.Data = "Hello wkrld!";

                DataStrone<int> intstire = new DataStrone<int>();
                intstire.Data = 123;
                //intstire.datas = [1,2,3];
                DataStrone<string> cities = new DataStrone<string>();

                cities.AddorUpdate(0, "Budapest");
            cities.AddorUpdate(1, "Bukarest");
            cities.AddorUpdate(2, "Bécs");

            Console.WriteLine(cities.Getdata(55));

            Console.ReadLine();
        }
        }
    }
